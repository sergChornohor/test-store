import GallerySlideshow from "./component/GallerySlideshow.vue";

export default GallerySlideshow;
