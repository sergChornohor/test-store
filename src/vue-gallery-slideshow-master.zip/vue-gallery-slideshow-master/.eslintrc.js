module.exports = {
  "extends": [
    "plugin:vue/recommended"
  ],
  "rules": {
    "semi": ["error", "always"],
    "quotes": ["error", "double"]
  }
};
